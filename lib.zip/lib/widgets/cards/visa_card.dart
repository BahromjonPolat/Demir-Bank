import 'package:flutter/material.dart';

class MasterCArd extends StatelessWidget {

  const MasterCArd({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(

    );
  }
}
