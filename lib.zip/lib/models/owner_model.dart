class OwnerModel {
  String? name;
  String?  email;
  String? password;
}