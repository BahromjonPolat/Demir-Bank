import 'package:demirbank/models/card_info_model.dart';
import 'package:demirbank/models/owner_model.dart';

class CardData {
  static List<CardInfoModel> cards = [
    CardInfoModel('Demir Bank', '1231 0877', '21/45', OwnerModel(), 'visa'),
  ];
}
