
class AppIcons {
  static const String home = 'assets/icons/home.svg';
  static const String payment = 'assets/icons/home.svg';
  static const String transactions = 'assets/icons/home.svg';
  static const String profile = 'assets/icons/home.svg';
}