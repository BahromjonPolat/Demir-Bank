class AppStrings{
  static const home = 'Главная';
  static const payment = 'Платежи';
}